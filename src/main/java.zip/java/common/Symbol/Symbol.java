package common.Symbol;

public record Symbol(String type, Object value) {
}
