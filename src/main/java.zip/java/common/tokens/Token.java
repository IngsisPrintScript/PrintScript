package common.tokens;

public record Token(String name, String value) {}
