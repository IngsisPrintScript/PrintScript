package common.tokens;

public interface TokenInterface {
    String name();
    String value();
}
